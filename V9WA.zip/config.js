/*

//================================//
      SETTING AJA SESUKA MU
//================================//

*/
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6288980337088']
global.premium = ['6288980337088']

//==========[ SET PAY ]===========//
global.dana = "088980337088"
global.ovo = "088980337088"
global.gopay = "088980337088"
global.qriss = "https://files.catbox.moe/vwh8cx.jpg"
//================================
global.thumb = "https://files.catbox.moe/3ncxbf.jpg"
global.urlfoto = "https://files.catbox.moe/3ncxbf.jpg"
global.url = "-"
global.namabot = "ᴇᴛᴇʀɴᴀʟ ɢʜᴏꜱᴛ"
global.packname = "WhatsApp Bot"
global.namaCreator = "t.me/XyZenXO2"
global.isLink = 'https://whatsapp.com/channel/0029VbBfpHDEKyZNL8xyhw24'
global.idSaluran = "120363418777559415@newsletter"