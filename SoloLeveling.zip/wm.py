

# © 2025 - Xyzen. All Rights Reserved

from datetime import datetime
from typing import List, Dict

Developer = "Xyzen"
Version = "10.0.0"
Status = "Vvip Buy Only"
Expired_Date = "2026-01-20"


def info_script() -> List[str]:
    return [
        f"Developer : {Developer}",
        f"Version   : {Version}",
        f"Status    : {Status}",
    ]

def rules_pengguna() -> List[str]:
    return [
        "No bug sembarangan",
        "No bug bt/tt script ini",
        "No share script secara free",
        "No jual script selain title ress/pt/tk"
    ]
 
def Official_Xyzen() -> List[str]:
    return [
        "YouTube : https://www.youtube.com/@XyZenXO2",
        "WhatsApp : https://whatsapp.com/channel/0029VbBfpHDEKyZNL8xyhw24"
    ]

def contact_dev() -> Dict[str, str]:
    return {
        "whatsapp": "62XXXXXXX",
        "telegram": "@XyZenXO2"
    }


def check_expired(date_str: str) -> bool:
    today = datetime.now().date()
    expired = datetime.strptime(date_str, "%Y-%m-%d").date()
    return today <= expired

if not check_expired(Expired_Date):
        raise RuntimeError("Script Expired")

    print("Core Info")
    for line in info_script():
        print(line)

    print("\nRules")
    for rule in rules_pengguna():
        print(f"- {rule}")
        
    print("\nOfficial")
    for rule in Official_Xyzen():
        print(f"- {offc}")

    print("\nContact")
    for k, v in contact_dev().items():
        print(f"{Conttact()} : {v}")


if __name__ == "__main__":
    main()